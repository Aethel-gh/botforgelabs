document.addEventListener("DOMContentLoaded", () => {
  // Invite button handler
  const inviteLink = "https://discord.com/oauth2/authorize?client_id=YOUR_BOT_ID&permissions=YOUR_PERMISSIONS&scope=bot";

  document.querySelectorAll('a[href="#invite"]').forEach((btn) => {
    btn.addEventListener("click", (e) => {
      e.preventDefault();
      window.open(inviteLink, "_blank", "noopener,noreferrer");
    });
  });

  // Smooth scroll for anchor links
  document.querySelectorAll('a[href^="#"]').forEach((link) => {
    link.addEventListener("click", (e) => {
      const href = link.getAttribute("href");
      if (href !== "#invite" && href !== "#") {
        const target = document.querySelector(href);
        if (target) {
          e.preventDefault();
          target.scrollIntoView({ behavior: "smooth" });
        }
      }
    });
  });
});